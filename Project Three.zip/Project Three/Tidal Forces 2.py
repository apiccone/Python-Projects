"""
Ashley Piccone

Project Three: Modeling Tidal Forces in 2D
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

dt = 5*10e-3
finalt = 5000
steps = int(finalt / dt)
time = np.linspace(0, finalt, steps)
N = 3

M = 5.972*10**24 # kg
R = 6.371*10**6 # m
G = 6.67*10**-11 # m**3 kg**-1 s**-2
mu = 1


""" Class definitions """

# this class defines the properties of a planet
class planet_point:
    def __init__(self,xpos,ypos):
        self.xpos = np.zeros(int(steps/1000))
        self.ypos = np.zeros(int(steps/1000))
        self.xvel = np.zeros(int(steps/1000))
        self.yvel = np.zeros(int(steps/1000))
        
# this class defines the properties of the body that causes tidal forces
class Moon:
    def __init__(self):
        # create the moon in terms of the Earth mass and radius
        self.mass = 7.347*10**22 / M
        self.radius = 1.737*10**6 / R
        self.xpos = np.zeros(steps)
        self.ypos = np.zeros(steps)
        self.xvel = np.zeros(steps)
        self.yvel = np.zeros(steps)
        
        
""" Create initial conditions """

# fill planet Earth's N points with different initial conditions
x = []
y = []
# x y quad
for i in range(int(R),0,-int(R/N/4)):
    x.append(i)
    y.append(np.sqrt(R**2 - i**2))   
# -x y quad
for i in range(0,int(R),int(R/N/4)):
    x.append(-i)
    y.append(np.sqrt(R**2 - i**2))  
# -x -y quad
for i in range(int(R),0,-int(R/N/4)):
    x.append(-i)
    y.append(-np.sqrt(R**2 - i**2))  
# x -y quad
for i in range(0,int(R),int(R/N/4)):
    x.append(i)
    y.append(-np.sqrt(R**2 - i**2))  

limit = len(x)

Earth = []
# append limit number of points to the Earth
for j in range(0,limit):
    Earth.append(planet_point(np.zeros(int(steps/1000)),np.zeros(int(steps/1000))))
    
# give these points a normalized radius
for j in range(0,limit):
    Earth[j].xpos[0] = x[j] / R
    Earth[j].ypos[0] = y[j] / R
         
# create the moon in terms of Earth mass and radius
Moon = Moon()
Moon.xpos[0] = 60
Moon.ypos[0] = 0
Moon.xvel[0] = 0
Moon.yvel[0] = 0.1


""" Finite differencing method to solve for Moon positions """

def orb_mech(pos,vel):
    for ii in range(0, steps-1):
        
        r = np.sqrt(pos[0][ii]**2 + pos[1][ii]**2)
        
        vel[0][ii+1] = dt * (-mu * pos[0][ii] / r**3) + vel[0][ii]
        vel[1][ii+1] = dt * (-mu * pos[1][ii] / r**3) + vel[1][ii]
        
        pos[0][ii+1] = vel[0][ii]*dt + pos[0][ii]
        pos[1][ii+1] = vel[1][ii]*dt + pos[1][ii]
               
    return pos[0], pos[1], vel[0], vel[1]
        
positions = np.zeros(2*steps).reshape((2,steps))
velocities = np.zeros(2*steps).reshape((2,steps))
for i in range(0,steps):
    positions[0][i] = Moon.xpos[i]
    positions[1][i] = Moon.ypos[i]
    velocities[0][i] = Moon.xvel[i]
    velocities[1][i] = Moon.yvel[i]

Moon.xpos, Moon.ypos, Moon.xvel, Moon.yvel = orb_mech(positions,velocities)

# stationary plot of x vs. y for the Moon's orbit
#fig = plt.figure()
#ax = fig.add_subplot(111, aspect='equal')
#plt.plot(Moon.xpos,Moon.ypos)
#ax.set_xlabel('X')
#ax.set_ylabel('Y')
#ax.set_title('Moon Orbit')
#plt.show()


""" Finite differencing method to solve for tidal forces """

def tidal_force(xpos,ypos,xvel,yvel,mx,my):
    for ii in range(0, int(steps/1000) - 1):
        
        d = np.sqrt((np.sqrt(mx**2 + my**2) - xpos[ii])**2 + ypos[ii]**2)
                
        xvel[ii+1] = xvel[ii] + dt * np.sign(mx) * (200000 * mu * xpos[ii] / d**3)
        yvel[ii+1] = yvel[ii] + dt * np.sign(my) * (200000 * mu * ypos[ii] / d**3)
        
        xpos[ii+1] = xvel[ii] * dt + xpos[ii]
        ypos[ii+1] = yvel[ii] * dt + ypos[ii]
               
    return xpos, ypos

index = 0

xp = []
yp = []
for kk in range(0,limit):
    p,q = tidal_force(Earth[kk].xpos,Earth[kk].ypos,Earth[kk].xvel,Earth[kk].yvel,Moon.xpos[index],Moon.ypos[index])
    xp.append(p)
    yp.append(q)

# plot the Earth's points and the moon
fig2 = plt.figure()
ax2 = fig2.add_subplot(111, aspect='equal', xlim=(-5, 80),ylim=(-5, 5))
ax2.set_xlabel('X')
ax2.set_ylabel('Y')
ax2.set_title('Earth and Moon')
for j in range(0,limit):
    plt.plot(Earth[j].xpos[0] , Earth[j].ypos[0], marker = 'o')
plt.plot(Moon.xpos[index], Moon.ypos[index], marker = '*')
plt.show()

# plot the strength of the tidal force with arrows
fig3 = plt.figure()
for kk in range(0,limit):
    ax3 = fig3.add_subplot(111, aspect='equal', xlim=(-2.5, 2.5),ylim=(-2.5, 2.5))
    ax3.arrow(xp[kk][0], yp[kk][0], xp[kk][10]-xp[kk][0], yp[kk][10]-yp[kk][0], head_width=0.05, head_length=0.1, fc='k', ec='k')
ax3.set_xlabel('X')
ax3.set_ylabel('Y')
ax3.set_title('Tidal Force')
plt.show()


""" Animation """

maxx = 1.25
maxy = 1.25 
minx = -1.25
miny = -1.25

fig = plt.figure()
ax = fig.add_subplot(111, aspect='equal', xlim=(minx, maxx),ylim=(miny, maxx))
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_title('Tidal Forces at Points on the Earth')

lines = []

for i in range(limit):
    line, = ax.plot([], [], 'o-')
    lines.append(line)

def init():
    for i in range(limit):
        lines[i].set_data([], [])
    return lines

def animate(i):
    thisx = []
    thisy = []
    for j in range(limit):
        thisx.append([])
        thisy.append([])

        thisx[j].append(xp[j][i])
        thisy[j].append(yp[j][i])

    for j in range(limit):
        lines[j].set_data(thisx[j],thisy[j])
        
    return lines

ani = animation.FuncAnimation(fig, animate, interval=1000, blit=True, init_func=init)
plt.show()


""" Attempt at a Runga Kutta method to solve for Earth point positions """
#
#def rk4(h,xn,yn,f,i,j,mx,my):
#    k1 = h*f(xn,yn,i,j,mx,my)
#    k2 = h*f(xn+h/2,yn+k1/2,i,j,mx,my)
#    k3 = h*f(xn+h/2,yn+k2/2,i,j,mx,my)
#    k4 = h*f(xn+h,yn+k3,i,j,mx,my)
#
#    return yn+k1/6+k2/3+k3/3+k4/6
#
## first derivative of x
#def f1(x,y,i,j,mx,my):
#    return xdarr[i][j]
#
## second derivative of x
#def f2(x,y,i,j,mx,my):
#    #xhat = mx - xarr[i][j]
#    #a = 2 * mu * xhat 
#    return 0
#
## first derivative of y
#def f3(x,y,i,j,mx,my):
#    return ydarr[i][j]
#
## second derivative of y
#def f4(x,y,i,j,mx,my):
#    #yhat = my - yarr[i][j]
#    #a = 2 * mu * yhat 
#    return 0
#
#def position(steps, finalt, dt, time, N, mx, my):
#    global xarr
#    global xdarr
#    global yarr
#    global ydarr
#    
#    xarr = np.zeros(steps * N).reshape(steps,N)
#    yarr = np.zeros(steps * N).reshape(steps,N)
#    xdarr = np.zeros(steps * N).reshape(steps,N)
#    ydarr = np.zeros(steps * N).reshape(steps,N)
#
#    # gets initial conditions back from each planet_point
#    for i in range(0,steps):
#        for j in range(0,N):
#            xarr[0][j] = Earth[j].xpos[0]
#            yarr[0][j] = Earth[j].ypos[0]
#
#    for i in range(0,steps-1):
#        for j in range(0,N):
#                xarr[i+1][j] = rk4(dt,time[i],xarr[i][j],f1,i,j,mx,my)
#                xdarr[i+1][j] = rk4(dt,time[i],xdarr[i][j],f2,i,j,mx,my)
#                yarr[i+1][j] = rk4(dt,time[i],yarr[i][j],f3,i,j,mx,my)
#                ydarr[i+1][j] = rk4(dt,time[i],ydarr[i][j],f4,i,j,mx,my)
#
#    # transpose position arrays
#    xnew = np.transpose(xarr)
#    ynew = np.transpose(yarr)
#
#    # assigns the new position arrays to the clothPoint objects
#    for i in range(0,steps):
#        for j in range(0,N):
#                Earth[j].xpos[i] = xnew[j][i]
#                Earth[j].ypos[i] = ynew[j][i]
#    
#    # stationary plot of x vs. y
##    for j in range(0,N):
##            plt.plot(xnew[j],ynew[j])
##            plt.xlabel('x')
##            plt.ylabel('y')
##    plt.show()
#    
#    return xnew, ynew
#
##xp, yp = position(steps, finalt, dt, time, limit, mx, my)

