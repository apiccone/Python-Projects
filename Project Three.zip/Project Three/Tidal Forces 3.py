"""
Ashley Piccone

Project Three: Modeling Tidal Forces in 3D
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.animation as animation

dt = 5*10e-3
finalt = 5000
steps = int(finalt / dt)
time = np.linspace(0, finalt, steps)
N = 1

M = 5.972*10**24 # kg
R = 6.371*10**6 # m
G = 6.67*10**-11 # m**3 kg**-1 s**-2
mu = 1


""" Class definitions """

# this class defines the properties of a planet
class planet_point:
    def __init__(self,xpos,ypos,zpos):
        self.xpos = np.zeros(int(steps/1000))
        self.ypos = np.zeros(int(steps/1000))
        self.zpos = np.zeros(int(steps/1000))
        
        self.xvel = np.zeros(int(steps/1000))
        self.yvel = np.zeros(int(steps/1000))
        self.zvel = np.zeros(int(steps/1000))
        
        
# this class defines the properties of the body that causes tidal forces
class Moon:
    def __init__(self):
        # create the moon in terms of the Earth mass and radius
        self.mass = 7.347*10**22 / M
        self.radius = 1.737*10**6 / R
        
        self.xpos = np.zeros(steps)
        self.ypos = np.zeros(steps)
        self.zpos = np.zeros(steps)
        
        self.xvel = np.zeros(steps)
        self.yvel = np.zeros(steps)
        self.zvel = np.zeros(steps)
        
        
""" Create initial conditions """

# fill planet Earth's N points with different initial conditions in the z = 0 plane
x = []
y = []
z = []
# z = 0 plane
# x y quad
for i in range(int(R),0,-int(R/N/12)):
    x.append(i)
    y.append(np.sqrt(R**2 - i**2)) 
    z.append(0)
# -x y quad
for i in range(0,int(R),int(R/N/12)):
    x.append(-i)
    y.append(np.sqrt(R**2 - i**2)) 
    z.append(0)
# -x -y quad
for i in range(int(R),0,-int(R/N/12)):
    x.append(-i)
    y.append(-np.sqrt(R**2 - i**2)) 
    z.append(0)
# x -y quad
for i in range(0,int(R),int(R/N/12)):
    x.append(i)
    y.append(-np.sqrt(R**2 - i**2)) 
    z.append(0)
# y = 0 plane
# x z quad
for i in range(int(R),0,-int(R/N/12)):
    x.append(i)
    y.append(0)
    z.append(np.sqrt(R**2 - i**2)) 
# -x z quad
for i in range(0,int(R),int(R/N/12)):
    x.append(-i)
    y.append(0)
    z.append(np.sqrt(R**2 - i**2)) 
# -x -z quad
for i in range(int(R),0,-int(R/N/12)):
    x.append(-i)
    y.append(0)
    z.append(-np.sqrt(R**2 - i**2)) 
# x -z quad
for i in range(0,int(R),int(R/N/12)):
    x.append(i)
    y.append(0)
    z.append(-np.sqrt(R**2 - i**2)) 
# x = 0 plane
# y z quad
for i in range(int(R),0,-int(R/N/12)):
    x.append(0)
    y.append(i)
    z.append(np.sqrt(R**2 - i**2)) 
# -y z quad
for i in range(0,int(R),int(R/N/12)):
    x.append(0)
    y.append(-i)
    z.append(np.sqrt(R**2 - i**2)) 
# -y -z quad
for i in range(int(R),0,-int(R/N/12)):
    x.append(0)
    y.append(-i)
    z.append(-np.sqrt(R**2 - i**2)) 
# y -z quad
for i in range(0,int(R),int(R/N/12)):
    x.append(0)
    y.append(i)
    z.append(-np.sqrt(R**2 - i**2)) 

# plot the Earth points
#fig = plt.figure()
#ax = fig.add_subplot(111, projection='3d')
#ax.set_title('Earth')
#ax.scatter(x,y,z)
#plt.show()

limit = len(x)

Earth = []
# append limit number of points to the Earth
for j in range(0,limit):
    Earth.append(planet_point(np.zeros(int(steps/1000)),np.zeros(int(steps/1000)),np.zeros(int(steps/1000))))
    
# give these points a normalized radius
for j in range(0,limit):
    Earth[j].xpos[0] = x[j] / R
    Earth[j].ypos[0] = y[j] / R
    Earth[j].zpos[0] = z[j] / R
         
# create the moon in terms of Earth mass and radius
Moon = Moon()
Moon.xpos[0] = 60
Moon.ypos[0] = 0
Moon.zpos[0] = 0
Moon.xvel[0] = 0
Moon.yvel[0] = 0.1
Moon.zvel[0] = 0


""" Finite differencing method to solve for Moon positions """

def orb_mech(pos,vel):
    for ii in range(0, steps-1):
        
        r = np.sqrt(pos[0][ii]**2 + pos[1][ii]**2 + pos[2][ii]**2)
        
        vel[0][ii+1] = dt * (-mu * pos[0][ii] / r**3) + vel[0][ii]
        vel[1][ii+1] = dt * (-mu * pos[1][ii] / r**3) + vel[1][ii]
        vel[2][ii+1] = dt * (-mu * pos[2][ii] / r**3) + vel[2][ii]
        
        pos[0][ii+1] = vel[0][ii]*dt + pos[0][ii]
        pos[1][ii+1] = vel[1][ii]*dt + pos[1][ii]
        pos[2][ii+1] = vel[2][ii]*dt + pos[2][ii]
               
    return pos[0], pos[1], pos[2]
        
positions = np.zeros(3*steps).reshape((3,steps))
velocities = np.zeros(3*steps).reshape((3,steps))
for i in range(0,steps):
    positions[0][i] = Moon.xpos[i]
    positions[1][i] = Moon.ypos[i]
    positions[2][i] = Moon.zpos[i]
    velocities[0][i] = Moon.xvel[i]
    velocities[1][i] = Moon.yvel[i]
    velocities[2][i] = Moon.zvel[i]

Moon.xpos, Moon.ypos, Moon.zpos = orb_mech(positions,velocities)

# stationary 3D plot of the Moon's orbit
#fig = plt.figure()
#ax = fig.add_subplot(111, projection='3d')
#ax.scatter(Moon.xpos,Moon.ypos,Moon.zpos)
#plt.show()


""" Finite differencing method to solve for tidal forces """

def tidal_force(xpos,ypos,zpos,xvel,yvel,zvel,mx,my,mz):
    for ii in range(0, int(steps/1000) - 1):
        
        d = np.sqrt((np.sqrt(mx**2 + my**2 + mz**2) - xpos[ii])**2 + ypos[ii]**2 + zpos[ii]**2)
                
        xvel[ii+1] = xvel[ii] + dt * np.sign(mx) * (200000 * mu * xpos[ii] / d**3)
        yvel[ii+1] = yvel[ii] + dt * np.sign(my) * (200000 * mu * ypos[ii] / d**3)
        zvel[ii+1] = zvel[ii] + dt * np.sign(mz) * (200000 * mu * zpos[ii] / d**3)
         
        xpos[ii+1] = xvel[ii] * dt + xpos[ii]
        ypos[ii+1] = yvel[ii] * dt + ypos[ii]
        zpos[ii+1] = zvel[ii] * dt + zpos[ii]
               
    return xpos, ypos, zpos

index = 0

xp = []
yp = []
zp = []
for kk in range(0,limit):
    p,q,s = tidal_force(Earth[kk].xpos,Earth[kk].ypos,Earth[kk].zpos,Earth[kk].xvel,Earth[kk].yvel,Earth[kk].zvel,Moon.xpos[index],Moon.ypos[index],Moon.zpos[index])
    xp.append(p)
    yp.append(q)
    zp.append(s)

# plot the Earth's points and the moon in the initial positions
fig2 = plt.figure()
ax2 = fig2.add_subplot(111, projection = '3d')
ax2.set_title('Moon Location')
for j in range(0,limit):
    ax2.scatter(Earth[j].xpos[0], Earth[j].ypos[0], Earth[j].zpos[0], marker = 'o')
ax2.scatter(Moon.xpos[index], Moon.ypos[index], Moon.zpos[index], marker = '*')
plt.show()

# plot the strength of the tidal force with arrows- not working in 3D
#fig3 = plt.figure()
#for kk in range(0,limit):
#    ax3 = fig3.add_subplot(111, projection = '3d')
#    ax3.quiver(xp[kk][0], yp[kk][0], zp[kk][0], xp[kk][100]-xp[kk][0], yp[kk][100]-yp[kk][0], zp[kk][100]-zp[kk][0])
#plt.show()


""" Animation """

fig = plt.figure()
ax = fig.add_subplot(111, projection = '3d')
ax.set_xlim3d(-1.25,1.25)
ax.set_ylim3d(-1.25,1.25)
ax.set_zlim3d(-1.25,1.25)
ax.set_title('Tidal Forces at Points on the Earth')

lines = []

for i in range(limit):
    line, = ax.plot([], [], [],'o-')
    lines.append(line)

def init():
    for i in range(limit):
        lines[i].set_data([], [])
        lines[i].set_3d_properties([])
    return lines

def animate(i):
    thisx = []
    thisy = []
    thisz = []
    
    for j in range(limit):
        thisx.append([])
        thisy.append([])
        thisz.append([])

        thisx[j].append(xp[j][i])
        thisy[j].append(yp[j][i])
        thisz[j].append(zp[j][i])

    for j in range(limit):
        lines[j].set_data(thisx[j],thisy[j])
        lines[j].set_3d_properties(thisz[j])
        
    return lines

ani = animation.FuncAnimation(fig, animate, interval=1000, blit=True, init_func=init)
plt.show()






