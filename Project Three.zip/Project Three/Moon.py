"""
Ashley Piccone

Project Three: Modeling Tidal Forces
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import math
import random as rand
from mpl_toolkits.mplot3d import Axes3D
import mpl_toolkits.mplot3d.axes3d as p3
import scipy.integrate as scint


dt = 5*10e-3
finalt = 5000
steps = int(finalt / dt)
time = np.linspace(0, finalt, steps)

M = 5.972*10**24 # kg
R = 6.371*10**6 # m
G = 6.67*10**-11 # m**3 kg**-1 s**-2
mu = 1

class Moon:
    def __init__(self):
        # create the moon in kg and m
        self.mass = 7.347*10**22 / M
        self.radius = 1.737*10**6 / R
        self.xpos = np.zeros(steps)
        self.ypos = np.zeros(steps)
        self.xvel = np.zeros(steps)
        self.yvel = np.zeros(steps)
        
# create the moon in kg and m
Moon = Moon()
Moon.xpos[0] = 60 
Moon.ypos[0] = 0
Moon.xvel[0] = 0
Moon.yvel[0] = 0.1#np.sqrt(2 * mu / 60)

plt.plot(Moon.xpos[0], Moon.ypos[0], marker = '*')
plt.show()

""" Finite differences method to solve for Moon positions """

def orb_mech(pos,vel):
    for ii in range(0, steps-1):
        
        r = np.sqrt(pos[0][ii]**2 + pos[1][ii]**2)
        
        vel[0][ii+1] = dt * (-mu * pos[0][ii] / r**3) + vel[0][ii]
        vel[1][ii+1] = dt * (-mu * pos[1][ii] / r**3) + vel[1][ii]
        
        pos[0][ii+1] = vel[0][ii]*dt + pos[0][ii]
        pos[1][ii+1] = vel[1][ii]*dt + pos[1][ii]
               
    return pos, vel
        
positions = np.zeros(2*steps).reshape((2,steps))
velocities = np.zeros(2*steps).reshape((2,steps))
for i in range(0,steps):
    positions[0][i] = Moon.xpos[i]
    positions[1][i] = Moon.ypos[i]
    velocities[0][i] = Moon.xvel[i]
    velocities[1][i] = Moon.yvel[i]

positions, velocities = orb_mech(positions,velocities)

plt.plot(positions[0],positions[1])
plt.show()
print(positions[0]) 
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
